package com.example.camstrm;

public class Config {

}
